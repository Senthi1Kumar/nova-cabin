"""Policy thresholds loaded from ``policy.yaml`` with ``${ENV:default}`` placeholders.

``DRIVEAUTH_*`` env vars override placeholder defaults. ``NOVA_*`` aliases remain
for Nova AI drop-in. Point ``DRIVEAUTH_POLICY_FILE`` at another YAML to swap the
whole pack without rebuilding.
"""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any

try:
    import yaml
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        "PyYAML is required to load driveauth/policy.yaml — "
        "install with: pip install 'driveauth-edge' (or PyYAML)"
    ) from exc

_PLACEHOLDER = re.compile(r"^\$\{([A-Za-z_][A-Za-z0-9_]*)(?::(.*))?\}$", re.DOTALL)

# DRIVEAUTH_* → NOVA_* legacy aliases (only when the DRIVEAUTH_ name is unset).
_LEGACY_ALIASES: dict[str, str] = {
    "DRIVEAUTH_RISK_APPROVE": "NOVA_RISK_APPROVE",
    "DRIVEAUTH_RISK_REJECT": "NOVA_RISK_REJECT",
    "DRIVEAUTH_TRUST_ACCEPT_MICRO": "NOVA_TRUST_ACCEPT_MICRO",
    "DRIVEAUTH_TRUST_ACCEPT_STD": "NOVA_TRUST_ACCEPT_STD",
    "DRIVEAUTH_TRUST_ACCEPT_HIGH": "NOVA_TRUST_ACCEPT_HIGH",
    "DRIVEAUTH_TRUST_REJECT": "NOVA_TRUST_REJECT",
    "DRIVEAUTH_CONF_FLOOR": "NOVA_CONF_FLOOR",
    "DRIVEAUTH_TIER_MICRO_MAX": "NOVA_TIER_MICRO_MAX",
    "DRIVEAUTH_TIER_HIGH_MIN": "NOVA_TIER_HIGH_MIN",
    "DRIVEAUTH_TIER_GUEST_MAX": "NOVA_TIER_GUEST_MAX",
    "DRIVEAUTH_POLICY_VERSION": "NOVA_POLICY_VERSION",
    "DRIVEAUTH_FRAUD_LADDER_DECAY_HOURS": "NOVA_FRAUD_LADDER_DECAY_HOURS",
    "DRIVEAUTH_FRAUD_CLEAN_STREAK": "NOVA_FRAUD_CLEAN_STREAK",
    "DRIVEAUTH_OTP_TTL_S": "NOVA_OTP_TTL_S",
    "DRIVEAUTH_OTP_LENGTH": "NOVA_OTP_LENGTH",
    "DRIVEAUTH_OTP_MAX_TRIES": "NOVA_OTP_MAX_TRIES",
    "DRIVEAUTH_OTP_PROVIDER_URL": "NOVA_OTP_PROVIDER_URL",
    "DRIVEAUTH_OTP_PROVIDER_TIMEOUT_S": "NOVA_OTP_PROVIDER_TIMEOUT_S",
    "DRIVEAUTH_STEP_UP_RETRIES": "NOVA_STEP_UP_RETRIES",
    "DRIVEAUTH_FINGERPRINT_AVAILABLE": "NOVA_FINGERPRINT_AVAILABLE",
    "DRIVEAUTH_TRUST_W_VOICE": "NOVA_TRUST_W_VOICE",
    "DRIVEAUTH_TRUST_W_FACE": "NOVA_TRUST_W_FACE",
    "DRIVEAUTH_TRUST_W_FINGER": "NOVA_TRUST_W_FINGER",
    "DRIVEAUTH_PIN_MIN_LEN": "NOVA_PIN_MIN_LEN",
    "DRIVEAUTH_ORCH_UNCERTAINTY": "NOVA_ORCH_UNCERTAINTY",
    "DRIVEAUTH_Q_VOICE_MIN_SNR": "NOVA_Q_VOICE_MIN_SNR",
    "DRIVEAUTH_Q_VOICE_CLIP_FRAC": "NOVA_Q_VOICE_CLIP_FRAC",
    "DRIVEAUTH_Q_VOICE_MIN_SEC": "NOVA_Q_VOICE_MIN_SEC",
    "DRIVEAUTH_Q_FACE_MIN_SHARP": "NOVA_Q_FACE_MIN_SHARP",
    "DRIVEAUTH_Q_FACE_MIN_BRIGHT": "NOVA_Q_FACE_MIN_BRIGHT",
    "DRIVEAUTH_Q_FACE_MAX_BRIGHT": "NOVA_Q_FACE_MAX_BRIGHT",
    "DRIVEAUTH_Q_FINGER_MIN_CONTACT": "NOVA_Q_FINGER_MIN_CONTACT",
    "DRIVEAUTH_OOD_Z_THRESH": "NOVA_OOD_Z_THRESH",
    "DRIVEAUTH_OOD_COSINE_THRESH": "NOVA_OOD_COSINE_THRESH",
    "DRIVEAUTH_IR_CAMERA_INDEX": "NOVA_IR_CAMERA_INDEX",
    "DRIVEAUTH_FINGER_SOCKET": "NOVA_FINGER_SOCKET",
}


def _env_lookup(name: str) -> str | None:
    v = os.getenv(name)
    if v is not None:
        return v
    legacy = _LEGACY_ALIASES.get(name)
    if legacy:
        return os.getenv(legacy)
    # Generic NOVA_* mirror for any DRIVEAUTH_* not listed above.
    if name.startswith("DRIVEAUTH_"):
        return os.getenv("NOVA_" + name[len("DRIVEAUTH_") :])
    return None


def _resolve_placeholders(node: Any) -> Any:
    if isinstance(node, dict):
        return {k: _resolve_placeholders(v) for k, v in node.items()}
    if isinstance(node, list):
        return [_resolve_placeholders(v) for v in node]
    if isinstance(node, str):
        m = _PLACEHOLDER.match(node.strip())
        if not m:
            return node
        name, default = m.group(1), m.group(2)
        found = _env_lookup(name)
        if found is not None:
            return found
        return "" if default is None else default
    return node


def _as_float(v: Any) -> float:
    return float(v)


def _as_int(v: Any) -> int:
    return int(float(v))


def _as_bool01(v: Any) -> bool:
    """Treat '1' / 'true' / 'yes' / True as enabled."""
    if isinstance(v, bool):
        return v
    return str(v).strip().lower() in ("1", "true", "yes", "on")


def _policy_path() -> Path:
    override = os.getenv("DRIVEAUTH_POLICY_FILE") or os.getenv("NOVA_POLICY_FILE")
    if override:
        return Path(override)
    return Path(__file__).resolve().parent / "policy.yaml"


def load_policy(path: Path | None = None) -> dict[str, Any]:
    p = path or _policy_path()
    with p.open(encoding="utf-8") as f:
        raw = yaml.safe_load(f) or {}
    if not isinstance(raw, dict):
        raise ValueError(f"policy file must be a mapping: {p}")
    return _resolve_placeholders(raw)


_P = load_policy()

# ── Public constants (same names as before — callers unchanged) ──────────────

POLICY_VERSION = str(_P["version"])

RISK_APPROVE = _as_float(_P["risk"]["approve"])
RISK_REJECT = _as_float(_P["risk"]["reject"])

TRUST_ACCEPT_MICRO = _as_float(_P["trust"]["accept_micro"])
TRUST_ACCEPT_STD = _as_float(_P["trust"]["accept_standard"])
TRUST_ACCEPT_HIGH = _as_float(_P["trust"]["accept_high"])
TRUST_REJECT = _as_float(_P["trust"]["reject"])
TRUST_W_VOICE = _as_float(_P["trust"]["weights"]["voice"])
TRUST_W_FACE = _as_float(_P["trust"]["weights"]["face"])
TRUST_W_FINGER = _as_float(_P["trust"]["weights"]["finger"])

# Modality score bars for Voice → Face → Finger ladder Accept.
_LADDER = _P.get("ladder", {}) or {}
LADDER_ACCEPT = _as_float(_LADDER.get("accept", TRUST_ACCEPT_MICRO))
LADDER_ACCEPT_VOICE = _as_float(_LADDER.get("accept_voice", LADDER_ACCEPT))
LADDER_ACCEPT_FACE = _as_float(_LADDER.get("accept_face", LADDER_ACCEPT))
LADDER_ACCEPT_FINGER = _as_float(_LADDER.get("accept_finger", LADDER_ACCEPT))
# Opt-in: 0 = off. Default 0.05 withholds borderline face+PAD early-stop.
FACE_BORDERLINE_MARGIN = _as_float(_LADDER.get("face_borderline_margin", 0.05))
# Stage-3: fingerprint and/or Bluetooth OTP (identity ladder only).
_STAGE3_MODE_RAW = str(_LADDER.get("stage3_mode", "finger_only")).strip().lower()
LADDER_STAGE3_MODE = (
    _STAGE3_MODE_RAW
    if _STAGE3_MODE_RAW in ("finger_only", "otp_only", "finger_or_otp")
    else "finger_only"
)
_STAGE3_ORDER_RAW = str(_LADDER.get("stage3_order", "finger,otp"))
LADDER_STAGE3_ORDER: tuple[str, ...] = tuple(
    p.strip().lower()
    for p in _STAGE3_ORDER_RAW.split(",")
    if p.strip().lower() in ("finger", "otp")
) or ("finger", "otp")

CONF_FLOOR = _as_float(_P["confidence"]["floor"])
CONF_DISAGREE_SPREAD = _as_float(_P["confidence"]["disagreement_spread"])
CONF_SINGLE_AGREE = _as_float(_P["confidence"]["single_modality_agreement"])
CONF_LOW_QUALITY = _as_float(_P["confidence"]["low_quality_bar"])
CONF_OOD_MISSING = _as_float(_P["confidence"]["ood_missing_penalty"])
CONF_BEHAVIOR_MISSING = _as_float(_P["confidence"]["behavioral_missing_penalty"])
CONF_SENSOR_GAP = _as_float(_P["confidence"]["sensor_gap_penalty"])
CONF_HW_FAULT = _as_float(_P["confidence"]["hardware_fault_penalty"])
CONF_W_AGREE = _as_float(_P["confidence"]["w_agreement"])
CONF_W_QUALITY = _as_float(_P["confidence"]["w_quality"])
CONF_W_OOD = _as_float(_P["confidence"]["w_ood"])

TIER_MICRO_MAX = _as_float(_P["tiers"]["micro_max"])
TIER_HIGH_MIN = _as_float(_P["tiers"]["high_min"])
TIER_GUEST_MAX = _as_float(_P["tiers"]["guest_max"])

FRAUD_LADDER_DECAY_HOURS = _as_float(_P["fraud"]["decay_hours"])
FRAUD_CLEAN_STREAK = _as_int(_P["fraud"]["clean_streak"])
FRAUD_RIGOR: dict[str, dict[str, Any]] = {
    k: dict(v) for k, v in _P["fraud"]["rigor"].items()
}

OTP_TTL_S = _as_float(_P["otp"]["ttl_s"])
OTP_LENGTH = _as_int(_P["otp"]["length"])
OTP_MAX_TRIES = _as_int(_P["otp"]["max_tries"])
OTP_PROVIDER_URL = str(_P["otp"]["provider_url"])
OTP_PROVIDER_TIMEOUT_S = _as_float(_P["otp"]["provider_timeout_s"])

STEP_UP_RETRIES = _as_int(_P["step_up"]["retries"])
PIN_MIN_LEN = _as_int(_P["step_up"]["pin_min_len"])
FALLBACK_MIN_TRUST = _as_float(_P["step_up"]["fallback_min_trust"])

FINGERPRINT_AVAILABLE = _as_bool01(_P["hardware"]["fingerprint_available"])
IR_CAMERA_INDEX = _as_int(_P["hardware"]["ir_camera_index"])
RGB_CAMERA_INDEX = _as_int(_P["hardware"].get("rgb_camera_index", 1))
FINGER_SOCKET = str(_P["hardware"]["finger_socket"])
FINGER_UART = str(_P["hardware"].get("finger_uart", "/dev/ttyUSB0"))
_FINGER_SENSOR_RAW = str(_P["hardware"].get("finger_sensor", "auto")).strip().lower()
FINGER_SENSOR = _FINGER_SENSOR_RAW if _FINGER_SENSOR_RAW else "auto"
_FACE_BACKEND_RAW = str(_P["hardware"].get("face_backend", "onnx")).strip().lower()
FACE_BACKEND = _FACE_BACKEND_RAW if _FACE_BACKEND_RAW in ("onnx", "hailo") else "onnx"
HAILO_HEF = str(_P["hardware"].get("hailo_hef", "") or "")
_CAMERA_BACKEND_RAW = str(_P["hardware"].get("camera_backend", "auto")).strip().lower()
CAMERA_BACKEND = (
    _CAMERA_BACKEND_RAW
    if _CAMERA_BACKEND_RAW in ("auto", "kinect", "opencv", "freenect")
    else "auto"
)
KINECT_INDEX = _as_int(_P["hardware"].get("kinect_index", 0))
IR_LIVENESS_ENABLED = _as_bool01(_P["hardware"].get("ir_liveness_enabled", 0))
IR_LIVENESS_THRESHOLD = _as_float(_P["hardware"].get("ir_liveness_threshold", 0.55))
IR_LIVENESS_ENSEMBLE = _as_bool01(_P["hardware"].get("ir_liveness_ensemble", 0))
RELAY_GPIO_PIN = _as_int(_P["hardware"].get("relay_gpio_pin", 17))

ESCALATION_ENABLED = _as_bool01(_P["escalation"]["enabled"])
ESCALATION_CONSTANT_TIME_MS = _as_float(_P["escalation"]["constant_time_ms"])

BOOTSTRAP_MIN_TXNS = _as_int(_P["bootstrap"]["min_txns"])
BOOTSTRAP_MIN_DAYS = _as_float(_P["bootstrap"]["min_days"])

# Secure-element key wrapping (software | tpm). Off by default.
_KEY_PROT_RAW = str(os.getenv("DRIVEAUTH_KEY_PROTECTOR", "software")).strip().lower()
KEY_PROTECTOR = _KEY_PROT_RAW if _KEY_PROT_RAW else "software"

# PIN at-rest KDF. OWASP Password Storage Cheat Sheet (2023): PBKDF2-HMAC-SHA256 ≥ 600k.
PIN_PBKDF2_ITERATIONS = max(
    100_000,
    _as_int(os.getenv("DRIVEAUTH_PIN_PBKDF2_ITERATIONS", "600000")),
)


def is_production() -> bool:
    """True when ``DRIVEAUTH_ENV`` / ``DRIVEAUTH_ENVIRONMENT`` is prod.

    Looked up at call time so tests can toggle it without reimporting. Used to
    default integrity checking ON (and to refuse demo-only score overrides)
    without flipping those guards for local/dev workflows.
    """
    raw = (
        os.getenv("DRIVEAUTH_ENV") or os.getenv("DRIVEAUTH_ENVIRONMENT") or ""
    ).strip().lower()
    return raw in ("prod", "production")


# Fleet telemetry pilot — explicit opt-in required for outbound posts.
FLEET_TELEMETRY_OPT_IN = _as_bool01(os.getenv("DRIVEAUTH_FLEET_TELEMETRY_OPT_IN", "0"))
FLEET_TELEMETRY_URL = str(os.getenv("DRIVEAUTH_FLEET_TELEMETRY_URL", "") or "").strip()
FLEET_TELEMETRY_INTERVAL_S = _as_float(os.getenv("DRIVEAUTH_FLEET_TELEMETRY_INTERVAL_S", "60"))
PROFILE_STALE_DAYS = _as_float(_P["bootstrap"]["stale_days"])
BOOTSTRAP_AMOUNT_CAP = _as_float(_P["bootstrap"]["amount_cap"])
PROFILE_SCHEMA_VERSION = _as_int(_P["bootstrap"]["schema_version"])

DECISION_CACHE_TTL_S = _as_float(_P["cache"]["decision_ttl_s"])

Q_VOICE_MIN_SNR = _as_float(_P["quality"]["voice_min_snr_db"])
Q_VOICE_CLIP_FRAC = _as_float(_P["quality"]["voice_clip_frac"])
Q_VOICE_MIN_SEC = _as_float(_P["quality"]["voice_min_seconds"])
Q_FACE_MIN_SHARP = _as_float(_P["quality"]["face_min_sharpness"])
Q_FACE_MIN_BRIGHT = _as_float(_P["quality"]["face_min_bright"])
Q_FACE_MAX_BRIGHT = _as_float(_P["quality"]["face_max_bright"])
FACE_MIN_FRAC = _as_float(_P["quality"]["face_min_frac"])
Q_FINGER_MIN_CONTACT = _as_float(_P["quality"]["finger_min_contact"])

OOD_Z_THRESH = _as_float(_P["ood"]["z_thresh"])
OOD_COSINE_THRESH = _as_float(_P["ood"]["cosine_thresh"])

ORCH_UNCERTAINTY = _as_float(_P["orchestrator"]["uncertainty_thresh"])

# Geo / home-learning (review fix #3).
TRUSTED_ZONE_RADIUS_KM = _as_float(_P["geo"]["trusted_zone_radius_km"])
HOME_LEARN_MIN_SAMPLES = _as_int(_P["geo"]["home_learn_min_samples"])
HOME_LEARN_MAX_ACCURACY_M = _as_float(_P["geo"]["home_learn_max_accuracy_m"])

# Risk-model load strictness (review fix #8). When true, a present-but-corrupt
# risk_gbt.onnx causes RiskModel.load to raise instead of silently degrading
# to the additive fallback -- a defensive default for a safety-critical head.
RISK_STRICT_LOAD = _as_bool01(_P["risk"]["strict_load"])

# Raw resolved tree for audit / dashboard introspection.
POLICY: dict[str, Any] = _P

# Stock defaults from policy.yaml placeholders (env ignored) — used for drift warnings.
_STOCK_BAR_KEYS: tuple[tuple[str, str, tuple[str, ...]], ...] = (
    ("DRIVEAUTH_LADDER_ACCEPT_VOICE", "ladder.accept_voice", ("ladder", "accept_voice")),
    ("DRIVEAUTH_LADDER_ACCEPT_FACE", "ladder.accept_face", ("ladder", "accept_face")),
    ("DRIVEAUTH_LADDER_ACCEPT_FINGER", "ladder.accept_finger", ("ladder", "accept_finger")),
    ("DRIVEAUTH_TRUST_ACCEPT_MICRO", "trust.accept_micro", ("trust", "accept_micro")),
    ("DRIVEAUTH_TRUST_ACCEPT_STD", "trust.accept_standard", ("trust", "accept_standard")),
    ("DRIVEAUTH_TRUST_ACCEPT_HIGH", "trust.accept_high", ("trust", "accept_high")),
    ("DRIVEAUTH_TRUST_REJECT", "trust.reject", ("trust", "reject")),
)


def _yaml_placeholder_default(raw: dict[str, Any], path: tuple[str, ...]) -> float | None:
    node: Any = raw
    for key in path:
        if not isinstance(node, dict) or key not in node:
            return None
        node = node[key]
    if not isinstance(node, str):
        try:
            return float(node)
        except (TypeError, ValueError):
            return None
    m = _PLACEHOLDER.match(node.strip())
    if not m or m.group(2) is None:
        return None
    try:
        return float(m.group(2))
    except ValueError:
        return None


def policy_bar_overrides(path: Path | None = None) -> list[dict[str, Any]]:
    """Return ladder/trust bars whose resolved value differs from YAML stock default."""
    p = path or _policy_path()
    with p.open(encoding="utf-8") as f:
        raw = yaml.safe_load(f) or {}
    if not isinstance(raw, dict):
        return []
    resolved = {
        "DRIVEAUTH_LADDER_ACCEPT_VOICE": LADDER_ACCEPT_VOICE,
        "DRIVEAUTH_LADDER_ACCEPT_FACE": LADDER_ACCEPT_FACE,
        "DRIVEAUTH_LADDER_ACCEPT_FINGER": LADDER_ACCEPT_FINGER,
        "DRIVEAUTH_TRUST_ACCEPT_MICRO": TRUST_ACCEPT_MICRO,
        "DRIVEAUTH_TRUST_ACCEPT_STD": TRUST_ACCEPT_STD,
        "DRIVEAUTH_TRUST_ACCEPT_HIGH": TRUST_ACCEPT_HIGH,
        "DRIVEAUTH_TRUST_REJECT": TRUST_REJECT,
    }
    out: list[dict[str, Any]] = []
    for env_name, _label, ypath in _STOCK_BAR_KEYS:
        stock = _yaml_placeholder_default(raw, ypath)
        if stock is None:
            continue
        cur = float(resolved[env_name])
        if abs(cur - stock) > 1e-9:
            out.append(
                {
                    "env": env_name,
                    "stock": stock,
                    "deployed": cur,
                    "delta": round(cur - stock, 4),
                    "env_set": _env_lookup(env_name) is not None,
                }
            )
    return out


def warn_policy_bar_overrides(*, stream=None) -> list[dict[str, Any]]:
    """Loud stderr + security-log banner when deployed bars ≠ ``policy.yaml`` stock.

    ``phases/phase2b_suggested.env`` lowers bars for demo UX — that must never be
    silent. Call after secrets/env load and before serving traffic.
    """
    import logging
    import sys

    overrides = policy_bar_overrides()
    if not overrides:
        return []
    out = stream if stream is not None else sys.stderr
    lines = [
        "",
        "!" * 72,
        "WARNING: POLICY BARS DIFFER FROM policy.yaml STOCK DEFAULTS",
        "!" * 72,
        "Deployed accept/reject thresholds are NOT the repo stock bars.",
        "If you sourced phases/phase2b_suggested.env (or set DRIVEAUTH_* bars),",
        "you are lowering the security floor for demo UX — not raising scores.",
        "",
        "Default (stock) thresholds vs current (deployed):",
        "",
    ]
    for row in overrides:
        lines.append(
            f"  {row['env']}: stock={row['stock']} → deployed={row['deployed']} "
            f"(delta={row['delta']:+.4f}"
            f"{', via env' if row['env_set'] else ', via policy file'})"
        )
    lines.extend(
        [
            "",
            "Reason: demo / calibration override (not a production security improvement).",
            "Stock ladder defaults: voice=0.72 face=0.70 finger=0.70",
            "Expected production: keep policy.yaml stock unless re-calibrated on "
            "fleet data with documented FAR/FRR.",
            "See docs/security-assumptions.md §6 (phase2b_suggested.env).",
            "!" * 72,
            "",
        ]
    )
    text = "\n".join(lines)
    print(text, file=out, flush=True)
    sec = logging.getLogger("driveauth.security")
    sec.warning(
        "POLICY BAR OVERRIDE: %d bar(s) differ from policy.yaml stock — demo mode risk. "
        "Details: %s",
        len(overrides),
        "; ".join(
            f"{r['env']} stock={r['stock']} deployed={r['deployed']} Δ={r['delta']:+.4f}"
            for r in overrides
        ),
    )
    return overrides


def manual_scores_permitted() -> bool:
    """Manual score injection is a demo/HW-stand-in. Blocked in production
    unless ``DRIVEAUTH_ALLOW_MANUAL_SCORES=1`` is also set."""
    allow = (os.getenv("DRIVEAUTH_ALLOW_MANUAL_SCORES") or "").strip().lower() in (
        "1",
        "true",
        "yes",
        "on",
    )
    if allow:
        return True
    return not is_production()


def warn_manual_scores(*, active: bool, refused: bool = False, stream=None) -> None:
    """Loud stderr banner when ``DRIVEAUTH_MANUAL_SCORES`` would override biometrics."""
    import logging
    import sys

    out = stream if stream is not None else sys.stderr
    if refused:
        lines = [
            "",
            "!" * 72,
            "WARNING: DRIVEAUTH_MANUAL_SCORES IGNORED IN PRODUCTION",
            "!" * 72,
            "Biometric score overrides are refused when DRIVEAUTH_ENV=production.",
            "Set DRIVEAUTH_ALLOW_MANUAL_SCORES=1 if you truly intend to inject scores.",
            "!" * 72,
            "",
        ]
    elif active:
        lines = [
            "",
            "!" * 72,
            "WARNING: DRIVEAUTH_MANUAL_SCORES IS ACTIVE",
            "!" * 72,
            "Real matcher scores are being replaced by env/file stand-ins.",
            "This is a HW/demo override — not production biometric evidence.",
            "Unset DRIVEAUTH_MANUAL_SCORES, or keep it off any production image.",
            "!" * 72,
            "",
        ]
    else:
        return
    print("\n".join(lines), file=out, flush=True)
    logging.getLogger("driveauth.security").warning(
        "DRIVEAUTH_MANUAL_SCORES %s",
        "refused (production)" if refused else "ACTIVE — scores overridden",
    )


# Call ``warn_policy_bar_overrides()`` after secrets/env load (see dashboard.server).
# Do not auto-emit at import — config often loads before secrets.env is applied.
