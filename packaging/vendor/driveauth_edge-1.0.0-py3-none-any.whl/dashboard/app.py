"""FastAPI application — DriveAuth pipeline API + dashboard."""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Any

import numpy as np
from contextlib import asynccontextmanager

from fastapi import FastAPI, File, Form, HTTPException, Request, Response, UploadFile
from fastapi.responses import FileResponse, HTMLResponse
from pydantic import BaseModel, Field

from dashboard.security import (
    SESSION_COOKIE,
    AdminAuth,
    admin_required,
    allow_insecure_dashboard,
    clear_session_cookie,
    configured_api_key,
    issue_session,
    request_has_admin_session,
    revoke_session,
    session_ui_html,
    set_session_cookie,
    verify_configured_key,
)
from dashboard.state import DashboardState

from driveauth import DriveAuth
from driveauth.audio_io import wav_bytes_to_float32
from driveauth.enrollment import (
    enroll_driver,
    ensure_driver_layout,
    enrollment_status,
    list_enroll_images,
    list_enroll_wavs,
    list_registered_drivers,
    save_face_jpeg,
    save_finger_scan,
    save_voice_wav_bytes,
    validate_driver_id,
)
from driveauth.consent import ConsentRequiredError, record_consent
from driveauth.purge import purge_driver
from driveauth.matchers.mock import (
    MOCK_FACE_DIM,
    MOCK_FINGER_DIM,
    MOCK_VOICE_DIM,
    MockBehavioralMonitor,
    MockFaceMatcher,
    MockFingerMatcher,
    MockVoiceMatcher,
)
from driveauth.profile_store import ProfileStore
from driveauth.secrets import (
    ensure_secrets_loaded,
    get_secret,
    google_maps_key,
    openrouter_configured,
)
from driveauth.standalone_session import IntentSlots, process_audio, process_transcript
from dashboard.dashboard import render_dashboard
from dashboard.fleet import render_fleet
from dashboard.improved_auth import render_improved_auth
from dashboard.register import render_register

ensure_secrets_loaded()

_ROOT = Path(__file__).resolve().parents[1]


def _data_root() -> Path:
    return Path(get_secret("DRIVEAUTH_DATA_ROOT", str(_ROOT / "data"))).expanduser().resolve()


def _unified_store() -> Path:
    """Register + auth share one store (standalone product path)."""
    raw = (
        get_secret("DRIVEAUTH_DASHBOARD_STORE")
        or get_secret("DRIVEAUTH_REGISTER_STORE")
        or ""
    ).strip()
    if raw:
        return Path(raw).expanduser().resolve()
    phase2a = _ROOT / "driveauth_store_phase2a"
    if phase2a.is_dir():
        return phase2a.resolve()
    tmp = Path(tempfile.mkdtemp(prefix="driveauth_dashboard_"))
    return tmp


def _register_store() -> Path:
    return _unified_store()


def _default_driver() -> str:
    return get_secret("DRIVEAUTH_DEFAULT_DRIVER", "driver1") or "driver1"


def _want_mock() -> bool:
    return get_secret("DRIVEAUTH_USE_MOCK", "0").strip() == "1"


def _fake_audio(seconds: float = 1.5, sr: int = 16_000) -> np.ndarray:
    # Speech-like energy variation so QualityGate SNR passes (pure sine ≈ 0 dB).
    n = int(sr * seconds)
    t = np.linspace(0, seconds, n, dtype=np.float32)
    rng = np.random.default_rng(0)
    envelope = 0.05 + 0.15 * (0.5 + 0.5 * np.sin(2 * np.pi * 3.0 * t))
    speech = envelope * np.sin(2 * np.pi * 180 * t)
    noise = 0.005 * rng.standard_normal(n).astype(np.float32)
    return (speech + noise).astype(np.float32)


def _load_auth(
    *,
    mature: bool = True,
    driver_id: str | None = None,
    use_mock: bool | None = None,
) -> DriveAuth:
    store = str(_unified_store())
    did = validate_driver_id(driver_id or _default_driver())
    mock = _want_mock() if use_mock is None else use_mock
    auth = DriveAuth.load(store_dir=store, driver_id=did, use_mock_matchers=mock)
    if mature:
        auth._profile.seed_mature()
    return auth


def _state(request: Request | None = None) -> DashboardState:
    """Resolve dashboard state from the FastAPI app (thread-safe cache)."""
    if request is None:
        raise RuntimeError(
            "DashboardState requires a FastAPI Request — pass request= from the endpoint"
        )
    state = getattr(request.app.state, "dashboard", None)
    if state is None:
        # TestClient without lifespan edge-case: install lazily.
        state = DashboardState()
        request.app.state.dashboard = state
    return state


def get_auth(
    request: Request | None = None,
    driver_id: str | None = None,
    *,
    use_mock: bool | None = None,
    mature: bool = True,
) -> DriveAuth:
    state = _state(request)
    did = validate_driver_id(driver_id or _default_driver())
    mock = _want_mock() if use_mock is None else use_mock
    store = str(_unified_store())
    key = (store, did, mock)
    with state.lock:
        if state.auth is None or state.auth_key != key:
            state.auth = _load_auth(mature=mature, driver_id=did, use_mock=mock)
            state.auth_key = key
        return state.auth


def reset_auth(
    request: Request | None = None,
    *,
    mature: bool = True,
    driver_id: str | None = None,
    use_mock: bool | None = None,
) -> DriveAuth:
    state = _state(request)
    state.clear()
    return get_auth(
        request=request, driver_id=driver_id, use_mock=use_mock, mature=mature
    )


def _decode_face_jpeg(raw: bytes) -> np.ndarray:
    try:
        import cv2
    except ImportError as exc:
        raise HTTPException(
            status_code=503, detail="opencv required for face: pip install -e '.[face]'"
        ) from exc
    arr = np.frombuffer(raw, dtype=np.uint8)
    bgr = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if bgr is None:
        raise HTTPException(status_code=400, detail="could not decode face JPEG")
    return bgr


def _apply_finger_manual(auth: DriveAuth, finger: float | None) -> None:
    auth._engine._m.finger = MockFingerMatcher(score=finger)
    auth._engine._m.fingerprint_available = finger is not None
    if not hasattr(auth._engine._m, "behavioral") or auth._engine._m.behavioral is None:
        auth._engine._m.behavioral = MockBehavioralMonitor(score=0.95)


def _profile_for(driver_id: str) -> ProfileStore:
    store = _unified_store()
    did = validate_driver_id(driver_id)
    return ProfileStore(store / "profiles" / f"{did}.json", did)


def _list_enrolled_drivers() -> list[dict[str, Any]]:
    store = _unified_store()
    faces = store / "faces"
    out: list[dict[str, Any]] = []
    if faces.is_dir():
        for p in sorted(faces.glob("*.enc")):
            did = p.stem
            home_lat, home_lon, home_n = _profile_for(did).home_coords()
            out.append(
                {
                    "driver_id": did,
                    "has_face": True,
                    "has_voice": (store / "voices" / f"{did}.enc").is_file(),
                    "home_lat": home_lat,
                    "home_lon": home_lon,
                    "home_set": home_n >= 1 and home_lat is not None,
                }
            )
    return out


class MockScores(BaseModel):
    voice: float = Field(0.92, ge=0.0, le=1.0)
    face: float = Field(0.88, ge=0.0, le=1.0)
    finger: float | None = Field(0.85, ge=0.0, le=1.0)
    behavioral: float = Field(0.95, ge=0.0, le=1.0)


class VehicleContext(BaseModel):
    speed_kmh: float = 0.0
    in_trusted_zone: bool = True
    dist_from_home_km: float = 0.0
    is_tunnel: bool = False
    ignition_on: bool = True
    gps_lat: float | None = None
    gps_lon: float | None = None
    gps_accuracy_m: float = 50.0


class AuthenticateRequest(BaseModel):
    amount: float = Field(150.0, ge=0.0)
    beneficiary: str = "Starbucks"
    beneficiary_known: bool = True
    is_guest: bool = False
    action: str = "pay"
    currency: str = "INR"
    channel: str = "dashboard"
    mock_scores: MockScores = Field(default_factory=MockScores)
    context: VehicleContext = Field(default_factory=VehicleContext)
    # Demo knobs that map onto existing engine fields (not new decision logic).
    fingerprint_available: bool | None = None
    stage3_mode: str | None = None
    otp_demo: bool = False


# Risk / policy reason codes already emitted by RiskModel / PolicyEngine.
_POLICY_TAG_CODES = (
    "first_time_beneficiary",
    "unfamiliar_location",
    "amount_far_above_usual",
    "large_absolute_amount",
    "unusual_hour",
    "transaction_while_moving",
    "driving_style_anomaly",
    "fraud_locked",
    "risk_above_hard_ceiling",
    "guest_mode_requires_pin",
    "ladder_exhausted_reject",
    "ood_baseline_missing",
    "modalities_disagree",
    "voice_unavailable",
    "face_unavailable",
    "ladder_finger_unavailable",
    "ladder_otp_unavailable",
)


class _DemoLadderOTP:
    """Always-available stage-3 OTP stand-in for dashboard scenarios."""

    def can_attempt(self) -> bool:
        return True

    def probe(self, verify_code: str | None = None):
        from driveauth.types import ModalityResult

        return ModalityResult(score=1.0, confident=True, available=True, latency_ms=4.0)


def _demo_mode_enabled() -> bool:
    return os.getenv("DRIVEAUTH_DEMO_MODE", "0").strip() == "1"


def _finger_daemon_reachable() -> bool:
    from driveauth import config

    path = str(getattr(config, "FINGER_SOCKET", "") or "")
    if not path:
        return False
    sock_path = Path(path)
    if not sock_path.exists():
        return False
    try:
        import socket

        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.settimeout(0.15)
        try:
            s.connect(path)
            return True
        finally:
            s.close()
    except OSError:
        return False


def _policy_tags(explanations: list[str]) -> list[str]:
    tags: list[str] = []
    for e in explanations or []:
        for code in _POLICY_TAG_CODES:
            if code in e and code not in tags:
                tags.append(code)
    return tags


def _decision_driver(result) -> dict[str, str]:
    """Derive which score lane drove the outcome from existing explanations."""
    expl = list(result.explanations or [])
    decision = result.decision.value
    if any("fraud_locked" in e for e in expl):
        return {"lane": "fraud", "summary": "REJECT — fraud lock"}
    if any("risk_above_hard_ceiling" in e for e in expl):
        return {"lane": "risk", "summary": "REJECT — risk ceiling exceeded"}
    if any("guest_mode_requires_pin" in e for e in expl):
        return {"lane": "policy", "summary": "STEP_UP — guest PIN required"}
    if decision == "ACCEPT":
        if result.stage3_method == "otp_bluetooth":
            return {"lane": "trust", "summary": "ACCEPT — stage-3 Bluetooth OTP"}
        if result.stage3_method == "finger":
            return {"lane": "trust", "summary": "ACCEPT — fingerprint"}
        for mod in ("voice", "face", "finger", "otp"):
            if any(e.startswith(f"ladder_accept_{mod}_") for e in expl):
                return {"lane": "trust", "summary": f"ACCEPT — {mod} cleared ladder"}
        return {"lane": "trust", "summary": "ACCEPT — ladder"}
    if decision == "REJECT":
        if any("ladder_exhausted" in e for e in expl):
            return {"lane": "trust", "summary": "REJECT — trust ladder exhausted"}
        return {"lane": "trust", "summary": "REJECT — biometric ladder"}
    if decision == "STEP_UP_REQUIRED":
        method = result.step_up_method or "required"
        return {"lane": "policy", "summary": f"STEP_UP — {method}"}
    return {"lane": "policy", "summary": decision}


def _pipeline_trace(result) -> dict[str, Any]:
    """Derive a stage-by-stage flow for the live dashboard visualization."""
    expl = list(result.explanations or [])
    mods = result.modality_scores or {}
    probed: list[str] = []
    for e in expl:
        if e.startswith("probed_"):
            raw = e.removeprefix("probed_")
            if raw and raw != "none":
                probed = [p for p in raw.split("+") if p]
            break

    def _mod_score(name: str) -> float | None:
        block = mods.get(name) or {}
        if not isinstance(block, dict):
            return None
        val = block.get("score")
        return float(val) if val is not None else None

    def _mod_available(name: str) -> bool:
        block = mods.get(name) or {}
        if not isinstance(block, dict):
            return True
        return bool(block.get("available", True))

    stage3_method = getattr(result, "stage3_method", None)
    ladder_stages: list[dict[str, Any]] = []
    # Voice / face are linear; stage-3 is an OR of finger | otp.
    early_order = ("voice", "face")
    accept_mod: str | None = None
    for mod in ("voice", "face", "finger", "otp"):
        if any(e.startswith(f"ladder_accept_{mod}_") for e in expl):
            accept_mod = mod
            break
    if accept_mod is None and result.policy_rule:
        for mod in ("voice", "face", "finger", "otp"):
            if f"ladder_accept_{mod}" in result.policy_rule:
                accept_mod = mod
                break
    if accept_mod is None and stage3_method == "finger":
        accept_mod = "finger"
    elif accept_mod is None and stage3_method == "otp_bluetooth":
        accept_mod = "otp"

    early_accept_idx = (
        early_order.index(accept_mod) if accept_mod in early_order else None
    )
    last_probed = probed[-1] if probed else None
    decided_reject = result.decision.value == "REJECT"

    next_unlock: str | None = None
    if accept_mod is None:
        if "voice" in probed and "face" not in probed:
            next_unlock = "face"
        elif "face" in probed and "finger" not in probed and "otp" not in probed:
            next_unlock = "finger"

    for mod in early_order:
        score = _mod_score(mod)
        idx = early_order.index(mod)
        if early_accept_idx is not None and idx > early_accept_idx:
            status, detail = "skipped", "early-stop · not probed"
        elif mod in probed:
            if accept_mod == mod:
                status = "accept"
                detail = f"≥ bar · {score:.3f}" if score is not None else "accepted"
            elif next_unlock and mod == last_probed:
                status = "escalate"
                detail = (
                    f"below bar · unlock {next_unlock}"
                    if score is not None
                    else f"no score · unlock {next_unlock}"
                )
            elif decided_reject and mod == last_probed:
                status = "reject"
                detail = f"exhausted · {score:.3f}" if score is not None else "exhausted"
            else:
                status = "escalate"
                detail = f"below bar · {score:.3f}" if score is not None else "no score"
        elif accept_mod is not None:
            status, detail = "skipped", "not needed"
        else:
            status, detail = "locked", "locked · not in this call"
        ladder_stages.append(
            {"id": mod, "label": mod.title(), "status": status, "score": score, "detail": detail}
        )

    # Stage-3 OR lanes (finger | Bluetooth OTP).
    stage3_lanes: list[dict[str, Any]] = []
    finger_probed = "finger" in probed
    otp_probed = "otp" in probed
    stage3_fallback = False
    for lane, label in (("finger", "Fingerprint"), ("otp", "Bluetooth OTP")):
        score = _mod_score(lane)
        available = _mod_available(lane)
        accepted = accept_mod == lane or (
            lane == "finger" and stage3_method == "finger"
        ) or (lane == "otp" and stage3_method == "otp_bluetooth")

        if early_accept_idx is not None:
            status, detail = "skipped", "early-stop · not needed"
        elif lane in probed:
            if accepted:
                status = "accept"
                detail = f"≥ bar · {score:.3f}" if score is not None else "accepted"
            elif decided_reject and lane == last_probed:
                status = "reject"
                detail = f"exhausted · {score:.3f}" if score is not None else "exhausted"
            else:
                status = "escalate"
                detail = (
                    "below bar · try other lane"
                    if score is not None
                    else "no score · try other lane"
                )
                if lane == "finger" and otp_probed:
                    stage3_fallback = True
                    detail = (
                        "below bar · OR → OTP"
                        if score is not None
                        else "no score · OR → OTP"
                    )
        elif not available or (lane == "finger" and not available and otp_probed):
            status = "unavailable"
            detail = "unavailable · OR → OTP" if otp_probed else "unavailable"
            if otp_probed and lane == "finger":
                stage3_fallback = True
        elif accepted:
            status, detail = "accept", "accepted"
        elif accept_mod in early_order:
            status, detail = "skipped", "not needed"
        elif (finger_probed or otp_probed) and lane not in probed:
            status, detail = "not_attempted", "not attempted"
        else:
            status, detail = "locked", "locked · not in this call"

        stage3_lanes.append(
            {
                "id": lane,
                "label": label,
                "status": status,
                "score": score,
                "detail": detail,
                "available": available,
            }
        )
        # Always expose finger + otp as addressable rungs (UI OR-lanes + tests).
        ladder_stages.append(
            {
                "id": lane,
                "label": label,
                "status": status,
                "score": score,
                "detail": detail,
                "stage3": True,
            }
        )

    hard_gate = None
    for key, label in (
        ("fraud_locked", "Fraud lock"),
        ("risk_above_hard_ceiling", "Risk ceiling"),
        ("guest_mode_requires_pin", "Guest PIN"),
    ):
        if any(key in e for e in expl):
            hard_gate = label
            break

    if hard_gate:
        next_unlock = None
        for rung in ladder_stages:
            if rung["id"] == last_probed and rung["status"] == "escalate":
                score = rung.get("score")
                rung["status"] = "reject"
                rung["detail"] = (
                    f"exhausted · {score:.3f}" if score is not None else "exhausted"
                )

    decision = result.decision.value
    if next_unlock:
        ladder_status = "stepup"
        ladder_detail = (
            f"{' → '.join(probed) if probed else '—'} · escalate · "
            f"unlock {next_unlock}"
        )
        policy_status, policy_detail = "hold", f"paused · capture {next_unlock}"
        decision_status, decision_detail = "hold", f"ESCALATE · {next_unlock}"
        path_summary = (
            f"{' → '.join(m.title() for m in probed)} → escalate · "
            f"unlock {next_unlock}"
            if probed
            else f"escalate · unlock {next_unlock}"
        )
    else:
        ladder_status = (
            "block"
            if decision == "REJECT" and hard_gate is None
            else "accept"
            if decision == "ACCEPT"
            else "stepup"
            if decision == "STEP_UP_REQUIRED"
            else "done"
        )
        early_stop = accept_mod
        if accept_mod == "otp":
            early_stop = "otp (Bluetooth)"
        ladder_detail = (
            f"probed {' → '.join(probed) if probed else '—'}"
            + (f" · early-stop {early_stop}" if early_stop else "")
        )
        policy_status = (
            "accept"
            if decision == "ACCEPT"
            else "stepup"
            if decision == "STEP_UP_REQUIRED"
            else "block"
        )
        policy_detail = result.policy_rule or "—"
        # Distinct REJECT status (not a neutral done/block swap).
        decision_status = (
            "reject"
            if decision == "REJECT"
            else "accept"
            if decision == "ACCEPT"
            else "stepup"
            if decision == "STEP_UP_REQUIRED"
            else "done"
        )
        decision_detail = decision
        path_summary = hard_gate or (
            f"{' → '.join(probed)} → {decision}"
            if probed
            else decision
        )

    driver = _decision_driver(result)

    stages = [
        {
            "id": "intent",
            "label": "Intent",
            "status": "done",
            "detail": f"{result.action or 'pay'} · {result.currency} {result.amount:g}",
        },
        {
            "id": "risk",
            "label": "Risk model",
            "status": "done",
            "detail": f"risk {result.risk_score:.3f} · tier {result.tier}",
        },
        {
            "id": "fraud",
            "label": "Fraud ladder",
            "status": "block" if hard_gate == "Fraud lock" else "done",
            "detail": hard_gate if hard_gate == "Fraud lock" else (result.fraud_state or "normal"),
        },
        {
            "id": "ladder",
            "label": "Bio ladder",
            "status": ladder_status,
            "detail": ladder_detail,
            "rungs": ladder_stages,
            "stage3_lanes": stage3_lanes,
            "stage3_fallback": stage3_fallback,
        },
        {
            "id": "policy",
            "label": "Policy",
            "status": policy_status,
            "detail": policy_detail,
        },
        {
            "id": "decision",
            "label": "Decision",
            "status": decision_status,
            "detail": decision_detail,
        },
    ]

    return {
        "stages": stages,
        "probed": probed,
        "accept_modality": accept_mod,
        "stage3_method": stage3_method,
        "stage3_fallback": stage3_fallback,
        "next_unlock": next_unlock,
        "pause_after": "ladder" if next_unlock else None,
        "hard_gate": hard_gate,
        "path_summary": path_summary,
        "decision_driver": driver,
    }


def _result_payload(result) -> dict[str, Any]:
    driver = _decision_driver(result)
    return {
        "decision": result.decision.value,
        "legacy_decision": result.legacy_decision,
        "trust_score": result.trust_score,
        "risk_score": result.risk_score,
        "confidence_score": result.confidence_score,
        "tier": result.tier,
        "policy_rule": result.policy_rule,
        "fraud_state": result.fraud_state,
        "step_up_method": result.step_up_method,
        "stage3_method": getattr(result, "stage3_method", None),
        "decision_driver": driver,
        "policy_tags": _policy_tags(list(result.explanations or [])),
        "explanations": result.explanations,
        "modality_scores": result.modality_scores,
        "active_thresholds": result.active_thresholds,
        "ood_flags": result.ood_flags,
        "pipeline": _pipeline_trace(result),
        "amount": result.amount,
        "currency": result.currency,
        "beneficiary": result.beneficiary,
        "action": result.action,
    }


def _apply_mock_scores(auth: DriveAuth, scores: MockScores) -> None:
    auth._engine._m.voice = MockVoiceMatcher(score=scores.voice)
    auth._engine._m.face = MockFaceMatcher(score=scores.face)
    auth._engine._m.finger = MockFingerMatcher(score=scores.finger)
    auth._engine._m.behavioral = MockBehavioralMonitor(score=scores.behavioral)
    auth._engine._m.fingerprint_available = scores.finger is not None
    # Keep OOD baselines aligned with mock embedding dims (MobileFaceNet=512).
    from driveauth.ood_detector import OODDetector

    auth._engine._ood = OODDetector.seed_baselines(
        auth._store,
        auth.driver_id,
        voice_dim=MOCK_VOICE_DIM,
        face_dim=MOCK_FACE_DIM,
        finger_dim=MOCK_FINGER_DIM,
    )


@asynccontextmanager
async def _lifespan(app: FastAPI):
    app.state.dashboard = DashboardState()
    reporter = None
    ble_server = None
    try:
        from driveauth import config
        from hardware.fleet_telemetry import (
            FleetTelemetryReporter,
            fleet_opt_in_enabled,
            live_sensor_flags,
        )

        if config.FLEET_TELEMETRY_OPT_IN and config.FLEET_TELEMETRY_URL:
            store = _unified_store()
            reporter = FleetTelemetryReporter(
                url=config.FLEET_TELEMETRY_URL,
                audit_path=store / "audit" / "driveauth_events.jsonl",
                sensor_flags=live_sensor_flags(),
                interval_s=config.FLEET_TELEMETRY_INTERVAL_S,
            )
            reporter.start()
            app.state.fleet_reporter = reporter

        if os.getenv("DRIVEAUTH_BLE_GATT_ENABLED", "0").strip() in ("1", "true", "yes"):
            from hardware.ble_gatt_server import BleGattServer

            ble_server = BleGattServer()
            if ble_server.start():
                app.state.ble_gatt_server = ble_server
    except Exception:
        app.state.fleet_reporter = None
    yield
    if ble_server is not None:
        try:
            ble_server.stop()
        except Exception:
            pass
    if reporter is not None:
        reporter.stop()
    app.state.dashboard.clear()


app = FastAPI(
    title="DriveAuth Edge Dashboard",
    description=(
        "Live Trust/Risk/Confidence pipeline tester with Nova I/O contract. "
        "Mutating admin endpoints require ``DRIVEAUTH_DASHBOARD_API_KEY`` "
        "(Bearer, X-API-Key, or an HttpOnly session cookie from "
        "``POST /api/admin/login``)."
    ),
    version="1.0.0",
    lifespan=_lifespan,
)


def _with_session_ui(html: str, request: Request) -> str:
    required = admin_required()
    authenticated = (not required) or request_has_admin_session(request)
    boot = session_ui_html(required=required, authenticated=authenticated)
    if "</head>" in html:
        return html.replace("</head>", boot + "\n</head>", 1)
    return boot + html


@app.get("/", response_class=HTMLResponse)
def index(request: Request) -> str:
    return _with_session_ui(render_dashboard(mode="standalone"), request)


@app.get("/manual", response_class=HTMLResponse)
def manual_page(request: Request) -> str:
    return _with_session_ui(render_dashboard(mode="manual"), request)


@app.get("/standalone", response_class=HTMLResponse)
def standalone_page(request: Request) -> str:
    return _with_session_ui(render_dashboard(mode="standalone"), request)


@app.get("/register", response_class=HTMLResponse)
def register_page(request: Request) -> str:
    return _with_session_ui(render_register(), request)


@app.get("/fleet", response_class=HTMLResponse)
def fleet_page(request: Request) -> str:
    return _with_session_ui(render_fleet(), request)


@app.get("/improved-auth", response_class=HTMLResponse)
def improved_auth_page(request: Request) -> str:
    return _with_session_ui(render_improved_auth(), request)


class AdminLoginRequest(BaseModel):
    api_key: str = Field("", min_length=0)


@app.post("/api/admin/login")
def admin_login(body: AdminLoginRequest, request: Request, response: Response) -> dict[str, Any]:
    expected = configured_api_key()
    if expected is None:
        if allow_insecure_dashboard():
            return {"ok": True, "mode": "insecure"}
        raise HTTPException(
            status_code=503,
            detail=(
                "DRIVEAUTH_DASHBOARD_API_KEY is not set. Configure a secret or set "
                "DRIVEAUTH_ALLOW_INSECURE_DASHBOARD=1 for local demos only."
            ),
        )
    if not verify_configured_key(body.api_key):
        raise HTTPException(status_code=401, detail="Invalid or missing dashboard API key")
    token = issue_session(request)
    set_session_cookie(request, response, token)
    return {"ok": True}


@app.post("/api/admin/logout")
def admin_logout(request: Request, response: Response) -> dict[str, Any]:
    revoke_session(request, request.cookies.get(SESSION_COOKIE))
    clear_session_cookie(response)
    return {"ok": True}


@app.get("/api/improved-auth/status")
def improved_auth_status_api(driver_id: str = "parth") -> dict[str, Any]:
    from driveauth.improved_auth import improved_auth_status

    try:
        return improved_auth_status(_data_root(), _register_store(), driver_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


class ImprovedAuthDriverRequest(BaseModel):
    driver_id: str = Field(..., min_length=1, max_length=32)


@app.post("/api/improved-auth/face")
async def improved_auth_face(
    _admin: AdminAuth,
    driver_id: str = Form(...),
    split: str = Form(...),
    file: UploadFile = File(...),
) -> dict[str, Any]:
    from driveauth.improved_auth import FACE_USER_SPLITS, improved_auth_status

    try:
        driver_id = validate_driver_id(driver_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    if split not in FACE_USER_SPLITS:
        raise HTTPException(
            status_code=400,
            detail=f"face split must be one of {FACE_USER_SPLITS}",
        )
    raw = await file.read()
    if not raw:
        raise HTTPException(status_code=400, detail="empty image upload")
    if len(raw) > 8_000_000:
        raise HTTPException(status_code=400, detail="image too large")
    # Soft framing check for side/replay — do not hard-reject side angles.
    path = save_face_jpeg(_data_root(), driver_id, raw, split=split)
    st = improved_auth_status(_data_root(), _register_store(), driver_id)
    rel = str(path.relative_to(_data_root()))
    return {
        "status": "ok",
        "path": rel,
        "data_path": f"data/{rel}",
        "abs_path": str(path),
        "split": split,
        **st,
    }


@app.post("/api/improved-auth/voice")
async def improved_auth_voice(
    _admin: AdminAuth,
    driver_id: str = Form(...),
    split: str = Form(...),
    file: UploadFile = File(...),
) -> dict[str, Any]:
    from driveauth.improved_auth import VOICE_USER_SPLITS, improved_auth_status

    try:
        driver_id = validate_driver_id(driver_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    if split not in VOICE_USER_SPLITS:
        raise HTTPException(
            status_code=400,
            detail=f"voice split must be one of {VOICE_USER_SPLITS}",
        )
    raw = await file.read()
    if not raw:
        raise HTTPException(status_code=400, detail="empty audio upload")
    if len(raw) > 8_000_000:
        raise HTTPException(status_code=400, detail="audio too large")
    try:
        path = save_voice_wav_bytes(_data_root(), driver_id, raw, split=split)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"invalid WAV: {exc}") from exc
    st = improved_auth_status(_data_root(), _register_store(), driver_id)
    rel = str(path.relative_to(_data_root()))
    return {
        "status": "ok",
        "path": rel,
        "data_path": f"data/{rel}",
        "abs_path": str(path),
        "split": split,
        **st,
    }


@app.post("/api/improved-auth/auto-fill")
def improved_auth_auto_fill(
    _admin: AdminAuth,
    req: ImprovedAuthDriverRequest,
) -> dict[str, Any]:
    from driveauth.improved_auth import (
        improved_auth_status,
        prepare_improved_auth_datasets,
    )

    try:
        driver_id = validate_driver_id(req.driver_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    try:
        prepared = prepare_improved_auth_datasets(_data_root(), driver_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    st = improved_auth_status(_data_root(), _register_store(), driver_id)
    return {"status": "ok", "prepared": prepared, **st}


@app.get("/api/improved-auth/preview/face/{driver_id}/{split}/{filename}")
def improved_auth_face_preview(
    driver_id: str, split: str, filename: str
) -> FileResponse:
    try:
        driver_id = validate_driver_id(driver_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    allowed = {
        "enroll",
        "genuine",
        "attack_replay_screen",
        "attack_side",
        "attack_blur",
    }
    if split not in allowed:
        raise HTTPException(status_code=400, detail="invalid split")
    safe = Path(filename).name
    if safe != filename or ".." in filename:
        raise HTTPException(status_code=400, detail="invalid filename")
    path = (_data_root() / driver_id / "face" / split / safe).resolve()
    root = (_data_root() / driver_id / "face" / split).resolve()
    if not str(path).startswith(str(root)) or not path.is_file():
        raise HTTPException(status_code=404, detail="not found")
    return FileResponse(path, media_type="image/jpeg")


@app.post("/api/improved-auth/train")
def improved_auth_train(
    _admin: AdminAuth,
    req: ImprovedAuthDriverRequest,
) -> dict[str, Any]:
    """Auto-fill blur/silent, then train Stage-2 heads (skip template re-enroll)."""
    import subprocess
    import sys

    from driveauth.improved_auth import (
        improved_auth_status,
        prepare_improved_auth_datasets,
    )

    try:
        driver_id = validate_driver_id(req.driver_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    data_dir = _data_root() / driver_id
    store = _register_store()
    st0 = improved_auth_status(_data_root(), store, driver_id)
    if not (st0["templates"]["face"] and st0["templates"]["voice"]):
        raise HTTPException(
            status_code=400,
            detail="enroll voice+face templates first on /register",
        )
    if not st0["face_user_ok"] or not st0["voice_user_ok"]:
        raise HTTPException(
            status_code=400,
            detail="capture the required face/voice attack boxes first (≥3 each)",
        )

    try:
        prepared = prepare_improved_auth_datasets(_data_root(), driver_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    py = sys.executable
    root = _ROOT
    logs: list[str] = []

    def _run(cmd: list[str]) -> None:
        env = os.environ.copy()
        env["DRIVEAUTH_STAGE2_RAW"] = "1"
        logs.append("$ " + " ".join(cmd))
        r = subprocess.run(
            cmd,
            cwd=str(root),
            env=env,
            capture_output=True,
            text=True,
        )
        if r.stdout:
            logs.append(r.stdout.strip())
        if r.stderr:
            logs.append(r.stderr.strip())
        if r.returncode != 0:
            raise HTTPException(
                status_code=500,
                detail={
                    "message": f"train step failed ({r.returncode})",
                    "cmd": cmd,
                    "log": "\n".join(logs[-40:]),
                },
            )

    common = [
        "--store",
        str(store),
        "--data",
        str(data_dir),
        "--driver-id",
        driver_id,
    ]
    _run(
        [
            py,
            str(root / "scripts" / "train_face_pad.py"),
            *common,
            "--exclude-fallback-crops",
        ]
    )
    _run([py, str(root / "scripts" / "train_face_calibrator.py"), *common])
    _run([py, str(root / "scripts" / "train_voice_calibrator.py"), *common])

    st = improved_auth_status(_data_root(), store, driver_id)
    return {
        "status": "ok",
        "driver_id": driver_id,
        "prepared": prepared,
        "log_tail": logs[-60:],
        **st,
    }


@app.get("/api/fleet/health")
def fleet_health(request: Request) -> dict[str, Any]:
    """Local fleet-health snapshot — scores/rates only, no biometrics."""
    from driveauth import __version__, config
    from hardware.fleet_telemetry import (
        build_telemetry_payload,
        fleet_opt_in_enabled,
        live_sensor_flags,
        summarize_audit_file,
    )

    store = _unified_store()
    audit = store / "audit" / "driveauth_events.jsonl"
    counts = summarize_audit_file(audit)
    reporter = getattr(request.app.state, "fleet_reporter", None)
    payload = build_telemetry_payload(
        vehicle_id=os.getenv("DRIVEAUTH_VEHICLE_ID", "local"),
        firmware_version=os.getenv("DRIVEAUTH_FIRMWARE_VERSION", __version__),
        accept_count=counts["accept"],
        reject_count=counts["reject"],
        step_up_count=counts["step_up"],
        sensor_flags=live_sensor_flags(),
    )
    ingest_path = store / "fleet_telemetry" / "ingest.jsonl"
    from hardware.fleet_telemetry import FleetTelemetryIngest

    ingest_count = len(FleetTelemetryIngest(ingest_path).recent(limit=10_000))
    payload["telemetry"] = {
        "opt_in": fleet_opt_in_enabled(),
        "url_configured": bool(config.FLEET_TELEMETRY_URL),
        "reporter_active": reporter is not None and getattr(reporter, "enabled", False),
        "send_count": int(getattr(reporter, "send_count", 0) or 0),
        "ingest_count": ingest_count,
    }
    return payload


class FleetTelemetryIngestRequest(BaseModel):
    model_config = {"populate_by_name": True}

    telemetry_schema: str = Field(
        default="driveauth.fleet_telemetry.v1", alias="schema"
    )
    vehicle_id: str = Field(..., min_length=1, max_length=64)
    firmware_version: str = "0.0.0"
    auth: dict[str, Any] = Field(default_factory=dict)
    sensors: dict[str, bool] = Field(default_factory=dict)
    ts: str | None = None


@app.post("/api/fleet/telemetry")
def fleet_telemetry_ingest(body: FleetTelemetryIngestRequest) -> dict[str, Any]:
    """Pilot ingest endpoint — accepts opt-in fleet rollups (no biometrics)."""
    from hardware.fleet_telemetry import FleetTelemetryIngest, build_telemetry_payload

    auth = body.auth or {}
    payload = build_telemetry_payload(
        vehicle_id=body.vehicle_id,
        firmware_version=body.firmware_version,
        accept_count=int(auth.get("accept", 0)),
        reject_count=int(auth.get("reject", 0)),
        step_up_count=int(auth.get("step_up", 0)),
        sensor_flags=body.sensors or {},
    )
    if body.ts:
        payload["ts"] = body.ts
    store = _unified_store()
    record = FleetTelemetryIngest(store / "fleet_telemetry" / "ingest.jsonl").ingest(
        payload
    )
    return {"status": "ok", "record": record}


@app.get("/api/fleet/telemetry")
def fleet_telemetry_recent(limit: int = 20) -> dict[str, Any]:
    from hardware.fleet_telemetry import FleetTelemetryIngest

    store = _unified_store()
    rows = FleetTelemetryIngest(store / "fleet_telemetry" / "ingest.jsonl").recent(
        limit=min(max(limit, 1), 200)
    )
    return {"status": "ok", "count": len(rows), "records": rows}


@app.get("/api/fleet/perf")
def fleet_perf() -> dict[str, Any]:
    """Local inference-latency / CPU-RAM panel — not a security audit."""
    from driveauth.perf_telemetry import get_default_telemetry

    return get_default_telemetry().summary()


@app.get("/api/register/drivers")
def register_drivers_list() -> list[dict[str, Any]]:
    return list_registered_drivers(_data_root(), _register_store())


class RegisterDriverRequest(BaseModel):
    driver_id: str = Field(..., min_length=1, max_length=32)


@app.get("/api/register/status")
def register_status(driver_id: str = "driver2") -> dict[str, Any]:
    try:
        return enrollment_status(_data_root(), _register_store(), driver_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


def _assert_register_writable(driver_id: str) -> None:
    """Block mutate APIs once voice+face templates are enrolled."""
    st = enrollment_status(_data_root(), _register_store(), driver_id)
    if st.get("locked"):
        raise HTTPException(
            status_code=403,
            detail=(
                f"{driver_id} is enrolled and locked — start a new Driver ID "
                "or continue a capturing (not enrolled) driver"
            ),
        )


@app.post("/api/register/init")
def register_init(
    _admin: AdminAuth,
    request: Request,
    req: RegisterDriverRequest,
) -> dict[str, Any]:
    try:
        driver_id = validate_driver_id(req.driver_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    _assert_register_writable(driver_id)
    try:
        root = ensure_driver_layout(_data_root(), driver_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {
        "status": "ok",
        "driver_id": driver_id,
        "data_dir": str(root),
        **enrollment_status(_data_root(), _register_store(), driver_id),
    }


@app.post("/api/register/face")
async def register_face(
    _admin: AdminAuth,
    request: Request,
    driver_id: str = Form(...),
    file: UploadFile = File(...),
) -> dict[str, Any]:
    try:
        driver_id = validate_driver_id(driver_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    _assert_register_writable(driver_id)
    raw = await file.read()
    if not raw:
        raise HTTPException(status_code=400, detail="empty image upload")
    if len(raw) > 8_000_000:
        raise HTTPException(status_code=400, detail="image too large")
    # Capture-time framing gate — same contract as scripts/capture_own_face.py.
    # Reject far-field / no-face snaps at enroll so audits don't discover them later.
    bgr = _decode_face_jpeg(raw)
    from driveauth.matchers.face import assess_face_framing

    framing = assess_face_framing(bgr)
    if not framing.get("ok"):
        raise HTTPException(
            status_code=400,
            detail=(
                f"face framing rejected ({framing.get('reason')}): "
                "move closer, face the camera, keep both eyes visible, then retake"
            ),
        )
    path = save_face_jpeg(_data_root(), driver_id, raw, split="enroll")
    st = enrollment_status(_data_root(), _register_store(), driver_id)
    return {
        "status": "ok",
        "path": str(path.relative_to(_data_root())),
        "face_frac": framing.get("face_frac"),
        "haar_ok": True,
        "haar_reason": framing.get("reason"),
        "eye_count": framing.get("eye_count"),
        "frontal_ok": framing.get("frontal_ok"),
        "face_clean_count": st.get("face_clean_count"),
        **st,
    }


@app.post("/api/register/voice")
async def register_voice(
    _admin: AdminAuth,
    request: Request,
    driver_id: str = Form(...),
    file: UploadFile = File(...),
) -> dict[str, Any]:
    try:
        driver_id = validate_driver_id(driver_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    _assert_register_writable(driver_id)
    raw = await file.read()
    if not raw:
        raise HTTPException(status_code=400, detail="empty audio upload")
    if len(raw) > 8_000_000:
        raise HTTPException(status_code=400, detail="audio too large")
    try:
        path = save_voice_wav_bytes(_data_root(), driver_id, raw, split="enroll")
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"invalid WAV: {exc}") from exc

    from driveauth.preprocess.voice import load_wav as load_voice_wav
    from driveauth.quality_gate import score_voice

    audio = load_voice_wav(path)
    ok, q, notes = score_voice(audio, 16_000)
    voice_quality = {
        "quality_ok": bool(ok),
        "quality": float(q),
        "duration_s": float(audio.size / 16_000),
        "notes": list(notes),
    }
    if not ok:
        path.unlink(missing_ok=True)
        raise HTTPException(
            status_code=400,
            detail=(
                "voice quality rejected "
                f"({', '.join(notes) or 'low_quality'}): "
                "speak clearly (audible speech), keep at least 1 second duration, reduce background noise, then retry"
            ),
        )

    return {
        "status": "ok",
        "path": str(path.relative_to(_data_root())),
        **voice_quality,
        **enrollment_status(_data_root(), _register_store(), driver_id),
    }


@app.post("/api/register/finger")
async def register_finger(
    _admin: AdminAuth,
    request: Request,
    driver_id: str = Form(...),
    file: UploadFile = File(...),
) -> dict[str, Any]:
    """Upload a 256×256 grayscale finger scan (65536 bytes) for optional enroll."""
    try:
        driver_id = validate_driver_id(driver_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    _assert_register_writable(driver_id)
    raw = await file.read()
    if not raw:
        raise HTTPException(status_code=400, detail="empty finger scan upload")
    if len(raw) < 256 * 256:
        raise HTTPException(
            status_code=400,
            detail=f"finger scan too short ({len(raw)} bytes; need 65536)",
        )
    try:
        path = save_finger_scan(_data_root(), driver_id, raw, split="enroll")
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {
        "status": "ok",
        "path": str(path.relative_to(_data_root())),
        "bytes": 256 * 256,
        **enrollment_status(_data_root(), _register_store(), driver_id),
    }


class RegisterCompleteRequest(BaseModel):
    driver_id: str = Field(..., min_length=1, max_length=32)
    # Explicit acknowledgment that biometric enrollment is consented.
    consent: bool = False
    consent_notes: str = ""


@app.post("/api/register/complete")
def register_complete(
    _admin: AdminAuth,
    request: Request,
    req: RegisterCompleteRequest,
) -> dict[str, Any]:
    try:
        driver_id = validate_driver_id(req.driver_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    _assert_register_writable(driver_id)
    if not req.consent:
        raise HTTPException(
            status_code=400,
            detail="consent required — set consent=true after informing the driver "
            "(BIPA/GDPR-class legal review still required for non-test drivers)",
        )
    profile = _profile_for(driver_id)
    home_lat, home_lon, _ = profile.home_coords()
    if home_lat is None or home_lon is None:
        raise HTTPException(
            status_code=400,
            detail="home location required — pin home on the map before enrolling",
        )
    data_dir = _data_root() / driver_id
    store = _register_store()
    record_consent(store, driver_id, notes=req.consent_notes or "dashboard /register")
    try:
        result = enroll_driver(store, data_dir, driver_id, require_minimums=True)
    except ConsentRequiredError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    return {"status": "ok", "home_lat": home_lat, "home_lon": home_lon, **result}


@app.post("/api/register/purge")
def register_purge(
    _admin: AdminAuth,
    request: Request,
    req: RegisterDriverRequest,
) -> dict[str, Any]:
    """Delete biometric templates + OOD + consent for a driver (Phase E)."""
    try:
        driver_id = validate_driver_id(req.driver_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    result = purge_driver(
        _register_store(),
        driver_id,
        data_root=_data_root(),
        remove_sample_files=False,
    )
    return {"status": "ok", **result}


@app.post("/api/register/clear")
def register_clear(
    _admin: AdminAuth,
    request: Request,
    req: RegisterDriverRequest,
) -> dict[str, Any]:
    try:
        driver_id = validate_driver_id(req.driver_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    _assert_register_writable(driver_id)
    data_dir = _data_root() / driver_id
    for path in list_enroll_images(data_dir) + list_enroll_wavs(data_dir):
        path.unlink(missing_ok=True)
    return {
        "status": "ok",
        **enrollment_status(_data_root(), _register_store(), driver_id),
    }


@app.get("/api/register/preview/face/{driver_id}/{filename}")
def register_face_preview(driver_id: str, filename: str) -> FileResponse:
    try:
        driver_id = validate_driver_id(driver_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    safe = Path(filename).name
    if safe != filename or ".." in filename:
        raise HTTPException(status_code=400, detail="invalid filename")
    path = (_data_root() / driver_id / "face" / "enroll" / safe).resolve()
    enroll_root = (_data_root() / driver_id / "face" / "enroll").resolve()
    if not path.is_relative_to(enroll_root) or not path.is_file():
        raise HTTPException(status_code=404, detail="not found")
    return FileResponse(path, media_type="image/jpeg")


@app.get("/api/status")
def status(request: Request) -> dict[str, Any]:
    auth = get_auth(use_mock=True, request=request)
    mature = auth._profile.is_mature()
    rigor = auth._fraud.effective_rigor(mature)
    home_lat, home_lon, home_n = auth._profile.home_coords()
    return {
        "store_dir": auth._store,
        "driver_id": auth.driver_id,
        "fraud_state": auth._fraud.effective_state(mature).value,
        "fraud_ladder": auth._fraud.state.value,
        "profile_mature": mature,
        "profile_maturity": auth._profile.maturity_reason(),
        "fraud_rigor": rigor,
        "enabled": auth._enabled,
        "use_mock": _want_mock(),
        "demo_mode": _demo_mode_enabled(),
        "openrouter": openrouter_configured(),
        "google_maps": bool(google_maps_key()),
        "home_lat": home_lat,
        "home_lon": home_lon,
        "home_set": home_n >= 1 and home_lat is not None,
    }


class HomeRequest(BaseModel):
    driver_id: str = Field(..., min_length=1, max_length=32)
    lat: float
    lon: float


@app.post("/api/register/home")
def register_home(
    _admin: AdminAuth,
    request: Request,
    req: HomeRequest,
) -> dict[str, Any]:
    try:
        driver_id = validate_driver_id(req.driver_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    _assert_register_writable(driver_id)
    if not (-90.0 <= req.lat <= 90.0 and -180.0 <= req.lon <= 180.0):
        raise HTTPException(status_code=400, detail="lat/lon out of range")
    profile = _profile_for(driver_id)
    profile.set_home(req.lat, req.lon)
    lat, lon, n = profile.home_coords()
    return {
        "status": "ok",
        "driver_id": driver_id,
        "home_lat": lat,
        "home_lon": lon,
        "home_n": n,
    }


@app.get("/api/standalone/config")
def standalone_config() -> dict[str, Any]:
    return {
        "openrouter": openrouter_configured(),
        "google_maps_api_key": google_maps_key(),
        "default_driver": _default_driver(),
        "store_dir": str(_unified_store()),
        "use_mock": _want_mock(),
        "drivers": _list_enrolled_drivers(),
    }


@app.get("/api/standalone/drivers")
def standalone_drivers() -> list[dict[str, Any]]:
    return _list_enrolled_drivers()


class IntentRequest(BaseModel):
    transcript: str = ""
    amount: float = 0.0
    beneficiary: str = ""
    action: str = "pay"
    currency: str = "INR"
    synthesize_tts: bool = True
    use_llm: bool = True


@app.post("/api/standalone/intent")
def standalone_intent(
    _admin: AdminAuth,
    request: Request,
    req: IntentRequest,
) -> dict[str, Any]:
    prior = IntentSlots(
        amount=req.amount,
        beneficiary=req.beneficiary,
        action=req.action or "pay",
        currency=req.currency or "INR",
        is_payment=bool(req.amount > 0 or req.beneficiary),
    )
    result = process_transcript(
        req.transcript,
        prior=prior if (prior.amount or prior.beneficiary) else None,
        use_llm=req.use_llm and openrouter_configured(),
        synthesize_tts=req.synthesize_tts and openrouter_configured(),
    )
    return result.as_dict()


@app.post("/api/standalone/transcribe")
async def standalone_transcribe(
    _admin: AdminAuth,
    request: Request,
    file: UploadFile = File(...),
    amount: float = Form(0.0),
    beneficiary: str = Form(""),
    action: str = Form("pay"),
    currency: str = Form("INR"),
    synthesize_tts: bool = Form(True),
    use_llm: bool = Form(True),
) -> dict[str, Any]:
    if not openrouter_configured():
        raise HTTPException(
            status_code=503,
            detail="OPENROUTER_API_KEY missing — fill secrets.env",
        )
    raw = await file.read()
    if not raw:
        raise HTTPException(status_code=400, detail="empty audio")
    if len(raw) > 12_000_000:
        raise HTTPException(status_code=400, detail="audio too large")
    prior = IntentSlots(
        amount=amount,
        beneficiary=beneficiary,
        action=action or "pay",
        currency=currency or "INR",
        is_payment=bool(amount > 0 or beneficiary),
    )
    fmt = "wav"
    if file.filename and "." in file.filename:
        fmt = file.filename.rsplit(".", 1)[-1].lower()
    result = process_audio(
        raw,
        audio_format=fmt,
        prior=prior if (prior.amount or prior.beneficiary) else None,
        use_llm=use_llm,
        synthesize_tts=synthesize_tts,
    )
    return result.as_dict()


@app.post("/api/standalone/auth")
async def standalone_auth(
    _admin: AdminAuth,
    request: Request,
    driver_id: str = Form(None),
    amount: float = Form(...),
    beneficiary: str = Form(...),
    action: str = Form("pay"),
    currency: str = Form("INR"),
    beneficiary_known: bool = Form(True),
    is_guest: bool = Form(False),
    finger: float | None = Form(None),
    behavioral: float = Form(0.95),
    gps_lat: float | None = Form(None),
    gps_lon: float | None = Form(None),
    gps_accuracy_m: float = Form(50.0),
    speed_kmh: float = Form(0.0),
    ignition_on: bool = Form(True),
    is_tunnel: bool = Form(False),
    audio: UploadFile = File(...),
    face: UploadFile | None = File(None),
) -> dict[str, Any]:
    """Live voice (+ optional face) auth; finger score stays manual when unlocked."""
    try:
        did = validate_driver_id(driver_id or _default_driver())
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    wav = await audio.read()
    if not wav:
        raise HTTPException(status_code=400, detail="empty audio")
    try:
        audio_np = wav_bytes_to_float32(wav)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"invalid WAV: {exc}") from exc

    face_bgr = None
    if face is not None:
        face_raw = await face.read()
        if face_raw:
            face_bgr = _decode_face_jpeg(face_raw)
            from driveauth.matchers.face import assess_face_framing

            framing = assess_face_framing(face_bgr)
            if not framing.get("ok"):
                raise HTTPException(
                    status_code=400,
                    detail=(
                        f"face framing rejected ({framing.get('reason')}): "
                        "move closer, face the camera, fill more of the frame, then retry"
                    ),
                )

    try:
        auth = get_auth(
            request=request, driver_id=did, use_mock=False, mature=True
        )
    except Exception as exc:
        raise HTTPException(
            status_code=503,
            detail=f"failed to load live matchers for {did}: {exc}",
        ) from exc

    m = auth._engine._m
    if isinstance(m.voice, MockVoiceMatcher) or isinstance(m.face, MockFaceMatcher):
        raise HTTPException(
            status_code=503,
            detail=(
                f"live matchers required for standalone auth (driver={did}); "
                "got MockVoiceMatcher/MockFaceMatcher — enroll voice/face or unset "
                "DRIVEAUTH_USE_MOCK"
            ),
        )

    # Progressive unlock: finger only when the client sends a score.
    _apply_finger_manual(auth, finger)
    auth._engine._m.behavioral = MockBehavioralMonitor(score=behavioral)

    face_matcher = getattr(auth._engine._m, "face", None)
    if face_bgr is not None and face_matcher is not None and hasattr(face_matcher, "inject_bgr"):
        face_matcher.inject_bgr(face_bgr)

    # GPS only — let ProfileStore compute dist_from_home / trusted zone.
    ctx: dict[str, Any] = {
        "speed_kmh": speed_kmh,
        "ignition_on": ignition_on,
        "is_tunnel": is_tunnel,
        "gps_accuracy_m": gps_accuracy_m,
    }
    if gps_lat is not None and gps_lon is not None:
        ctx["gps_lat"] = gps_lat
        ctx["gps_lon"] = gps_lon
        # Leave dist/zone at RiskContext defaults so apply_to_context fills them.
        ctx["dist_from_home_km"] = 0.0
        ctx["in_trusted_zone"] = True
    auth.update_vehicle_context(**ctx)
    auth.update_behavioral(
        {"vehicle_speed_kmh": speed_kmh, "ignition_on": float(ignition_on)}
    )

    result = auth.authenticate(
        audio_np=audio_np,
        amount=float(amount),
        beneficiary=beneficiary,
        action=action,
        currency=currency,
        channel="standalone",
        beneficiary_known=beneficiary_known,
        is_guest=is_guest,
        event="standalone_auth",
        # Face locked until the client supplies a JPEG (after voice escalates).
        face_expected=face_bgr is not None,
    )
    payload = _result_payload(result)
    if gps_lat is not None and gps_lon is not None:
        dist, zone = auth._profile.location_context(gps_lat, gps_lon)
        payload["dist_from_home_km"] = dist
        payload["in_trusted_zone"] = zone
        payload["gps_lat"] = gps_lat
        payload["gps_lon"] = gps_lon
    return payload


@app.post("/api/context")
def update_context(
    _admin: AdminAuth,
    request: Request,
    ctx: VehicleContext,
) -> dict[str, Any]:
    auth = get_auth(use_mock=True, request=request)
    data = {k: v for k, v in ctx.model_dump().items() if v is not None}
    # When GPS is provided without an explicit distance override, keep
    # dist_from_home_km=0 / in_trusted_zone=True so ProfileStore fills them.
    if ctx.gps_lat is not None and ctx.gps_lon is not None:
        data.setdefault("dist_from_home_km", 0.0)
        data.setdefault("in_trusted_zone", True)
    auth.update_vehicle_context(**data)
    auth.update_behavioral(
        {"vehicle_speed_kmh": ctx.speed_kmh, "ignition_on": float(ctx.ignition_on)}
    )
    out: dict[str, Any] = {"status": "ok"}
    if ctx.gps_lat is not None and ctx.gps_lon is not None:
        dist, zone = auth._profile.location_context(ctx.gps_lat, ctx.gps_lon)
        out["dist_from_home_km"] = dist
        out["in_trusted_zone"] = zone
    return out


@app.post("/api/authenticate")
def authenticate(
    _admin: AdminAuth,
    request: Request,
    req: AuthenticateRequest,
) -> dict[str, Any]:
    auth = get_auth(use_mock=_want_mock(), request=request)
    if _want_mock():
        _apply_mock_scores(auth, req.mock_scores)
    if req.fingerprint_available is not None:
        auth._engine._m.fingerprint_available = bool(req.fingerprint_available)

    prev_otp = auth._engine._ladder_otp
    if req.otp_demo:
        auth._engine._ladder_otp = _DemoLadderOTP()

    ctx = req.context.model_dump()
    # Drop null GPS so RiskContext keeps Optional defaults cleanly
    ctx = {k: v for k, v in ctx.items() if v is not None}
    auth.update_vehicle_context(**ctx)
    auth.update_behavioral(
        {
            "vehicle_speed_kmh": req.context.speed_kmh,
            "ignition_on": float(req.context.ignition_on),
        }
    )

    stage3 = None
    if req.stage3_mode:
        mode = str(req.stage3_mode).strip().lower()
        if mode in ("finger_only", "otp_only", "finger_or_otp"):
            stage3 = mode

    audio = _fake_audio()
    try:
        result = auth.authenticate(
            audio_np=audio,
            amount=req.amount,
            beneficiary=req.beneficiary,
            action=req.action,
            currency=req.currency,
            channel=req.channel,
            beneficiary_known=req.beneficiary_known,
            is_guest=req.is_guest,
            event="dashboard_auth",
            stage3_mode=stage3,
        )
    finally:
        if req.otp_demo:
            auth._engine._ladder_otp = prev_otp
    return _result_payload(result)


@app.get("/api/audit")
def audit(
    request: Request,
    limit: int = 50,
) -> list[dict[str, Any]]:
    auth = get_auth(use_mock=True, request=request)
    path = Path(auth._store) / "audit" / "driveauth_events.jsonl"
    if not path.exists():
        return []
    lines = path.read_text(encoding="utf-8").strip().splitlines()
    entries: list[dict[str, Any]] = []
    for line in lines[-limit:]:
        try:
            entries.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return list(reversed(entries))


@app.get("/api/audit/verify")
def audit_verify(request: Request) -> dict[str, Any]:
    """Read-only hash-chain check via AuditLog.verify_chain()."""
    auth = get_auth(use_mock=True, request=request)
    ok, reason = auth._audit.verify_chain()
    return {"ok": bool(ok), "reason": reason, "demo_mode": _demo_mode_enabled()}


@app.post("/api/audit/demo_tamper")
def audit_demo_tamper(_admin: AdminAuth, request: Request) -> dict[str, Any]:
    """Corrupt one byte of the audit file — only when DRIVEAUTH_DEMO_MODE=1."""
    if not _demo_mode_enabled():
        raise HTTPException(
            status_code=403,
            detail="demo tamper disabled — set DRIVEAUTH_DEMO_MODE=1",
        )
    auth = get_auth(use_mock=True, request=request)
    path = Path(auth._store) / "audit" / "driveauth_events.jsonl"
    if not path.is_file() or path.stat().st_size < 2:
        raise HTTPException(status_code=400, detail="audit log empty — run authenticate first")
    raw = bytearray(path.read_bytes())
    # Prefer flipping a hex nibble inside entry_hash so the line often remains
    # parseable JSON but fails the hash check; fall back to midpoint flip
    # (strict verify_chain still treats unparseable lines as tamper).
    text = raw.decode("utf-8", errors="replace")
    marker = '"entry_hash": "'
    idx = text.find(marker)
    if idx >= 0:
        # First hex char of the hash value.
        idx = idx + len(marker)
        if idx < len(raw) and chr(raw[idx]) in "0123456789abcdef":
            raw[idx] = ord("0") if raw[idx] != ord("0") else ord("1")
        else:
            idx = max(0, len(raw) // 2)
            raw[idx] = (raw[idx] + 1) % 256
    else:
        idx = max(0, len(raw) // 2)
        raw[idx] = (raw[idx] + 1) % 256
    path.write_bytes(bytes(raw))
    ok, reason = auth._audit.verify_chain()
    return {
        "tampered": True,
        "byte_index": idx,
        "verify": {"ok": bool(ok), "reason": reason},
    }


def _stage2_dashboard_status(auth) -> dict[str, Any]:
    """Per-driver Stage-2 snapshot for dashboard banners."""
    from driveauth.stage2_artifacts import stage2_status_for_driver

    store = Path(auth._store)
    s2 = stage2_status_for_driver(store, auth.driver_id)
    face_info = getattr(auth._engine._m.face, "stage2_info", {}) or {}
    voice_info = getattr(auth._engine._m.voice, "stage2_info", {}) or {}
    return {
        **s2,
        "face_runtime": face_info,
        "voice_runtime": voice_info,
        "pad_enabled_runtime": bool(getattr(auth._engine._m.face, "has_pad", False)),
    }


def _threshold_dashboard_status() -> dict[str, Any]:
    from driveauth import config
    from driveauth.config import policy_bar_overrides

    overrides = policy_bar_overrides()
    return {
        "mode": "demo_override" if overrides else "stock",
        "demo_banner": bool(overrides) or _demo_mode_enabled(),
        "stock": {
            "ladder_voice": 0.72,
            "ladder_face": 0.70,
            "ladder_finger": 0.70,
        },
        "current": {
            "ladder_voice": float(config.LADDER_ACCEPT_VOICE),
            "ladder_face": float(config.LADDER_ACCEPT_FACE),
            "ladder_finger": float(config.LADDER_ACCEPT_FINGER),
            "trust_micro": float(config.TRUST_ACCEPT_MICRO),
            "trust_std": float(config.TRUST_ACCEPT_STD),
            "trust_high": float(config.TRUST_ACCEPT_HIGH),
            "trust_reject": float(config.TRUST_REJECT),
        },
        "overrides": overrides,
    }


@app.get("/api/stage2_status")
def stage2_status(request: Request) -> dict[str, Any]:
    """Current driver Stage-2 artifact source, PAD, calibration, threshold mode."""
    auth = get_auth(use_mock=_want_mock(), request=request)
    return {
        "driver_id": auth.driver_id,
        "demo_mode": _demo_mode_enabled(),
        "stage2": _stage2_dashboard_status(auth),
        "thresholds": _threshold_dashboard_status(),
    }


@app.get("/api/modality_sources")
def modality_sources(request: Request) -> dict[str, Any]:
    """Real-vs-simulated labels from live config + reachability (not hardcoded)."""
    from driveauth import config
    from driveauth.matchers.mock import (
        MockBehavioralMonitor,
        MockFaceMatcher,
        MockFingerMatcher,
        MockVoiceMatcher,
    )

    auth = get_auth(use_mock=_want_mock(), request=request)
    m = auth._engine._m
    voice_mock = isinstance(m.voice, MockVoiceMatcher)
    face_mock = isinstance(m.face, MockFaceMatcher)
    finger_mock = isinstance(m.finger, MockFingerMatcher)
    beh_mock = isinstance(getattr(m, "behavioral", None), MockBehavioralMonitor)
    daemon_up = _finger_daemon_reachable()
    face_backend = str(getattr(config, "FACE_BACKEND", "onnx") or "onnx")
    # Hailo: only claim configured when backend is hailo AND matcher is not mock.
    ir_on = bool(getattr(config, "IR_LIVENESS_ENABLED", False))
    ir_attached = getattr(auth._engine, "_ir_liveness", None) is not None

    def _bio_label(is_mock: bool) -> str:
        return "manual stand-in" if is_mock else "real model"

    if daemon_up:
        finger_label = "real daemon protocol"
    elif finger_mock:
        finger_label = "manual stand-in"
    else:
        finger_label = "real model"

    return {
        "demo_mode": _demo_mode_enabled(),
        "use_mock": _want_mock(),
        "face_backend": face_backend,
        "driver_id": auth.driver_id,
        "hailo_status": (
            "configured (hailo)"
            if face_backend == "hailo" and not face_mock
            else "Hailo bench pending hardware"
        ),
        "stage2": _stage2_dashboard_status(auth),
        "thresholds": _threshold_dashboard_status(),
        "modalities": {
            "voice": {
                "label": _bio_label(voice_mock),
                "mock": voice_mock,
                "calibrator": getattr(m.voice, "has_calibrator", False),
                "calibrator_source": (getattr(m.voice, "stage2_info", {}) or {}).get(
                    "calibrator_source"
                ),
            },
            "face": {
                "label": _bio_label(face_mock),
                "mock": face_mock,
                "backend": face_backend,
                "pad_enabled": getattr(m.face, "has_pad", False),
                "calibrator": getattr(m.face, "has_calibrator", False),
                "stage2": getattr(m.face, "stage2_info", {}) or {},
            },
            "finger": {
                "label": finger_label,
                "mock": finger_mock,
                "daemon_reachable": daemon_up,
            },
            "liveness": {
                "label": (
                    "real model"
                    if ir_on and ir_attached
                    else "manual stand-in"
                ),
                "enabled": ir_on,
                "attached": ir_attached,
            },
            "can": {
                "label": "manual stand-in" if beh_mock else "real model",
                "mock": beh_mock,
            },
        },
    }


@app.post("/api/fraud/soft-flag")
def fraud_soft_flag(
    _admin: AdminAuth,
    request: Request,
    reason: str = "dashboard_test",
) -> dict[str, Any]:
    auth = get_auth(use_mock=True, request=request)
    state = auth._fraud.record_soft_flag(reason)
    return {"fraud_state": state.value, "rigor": auth._fraud.rigor()}


@app.post("/api/fraud/clean")
def fraud_clean(_admin: AdminAuth, request: Request) -> dict[str, Any]:
    auth = get_auth(use_mock=True, request=request)
    state = auth._fraud.record_clean()
    return {"fraud_state": state.value, "rigor": auth._fraud.rigor()}


@app.post("/api/fraud/reset")
def fraud_reset(_admin: AdminAuth, request: Request) -> dict[str, Any]:
    auth = get_auth(use_mock=True, request=request)
    auth._fraud.reset()
    return {"fraud_state": auth._fraud.state.value, "rigor": auth._fraud.rigor()}


@app.post("/api/reset")
def reset_session(
    _admin: AdminAuth,
    request: Request,
    mature: bool = True,
) -> dict[str, Any]:
    auth = reset_auth(mature=mature, use_mock=True, request=request)
    return {
        "status": "ok",
        "store_dir": auth._store,
        "profile_mature": auth._profile.is_mature(),
        "fraud_state": auth._fraud.effective_state(auth._profile.is_mature()).value,
    }


@app.post("/api/profile/mature")
def profile_mature(_admin: AdminAuth, request: Request) -> dict[str, Any]:
    auth = get_auth(use_mock=True, request=request)
    auth._profile.seed_mature()
    mature = True
    return {
        "profile_mature": mature,
        "profile_maturity": auth._profile.maturity_reason(),
        "fraud_state": auth._fraud.effective_state(mature).value,
    }


@app.post("/api/profile/bootstrap")
def profile_bootstrap(_admin: AdminAuth, request: Request) -> dict[str, Any]:
    auth = get_auth(use_mock=True, request=request)
    auth._profile.reset_bootstrap()
    mature = False
    return {
        "profile_mature": mature,
        "profile_maturity": auth._profile.maturity_reason(),
        "fraud_state": auth._fraud.effective_state(mature).value,
    }


@app.get("/api/scenarios")
def scenarios() -> list[dict[str, Any]]:
    return [
        {
            "id": "genuine_driver",
            "label": "Genuine driver (ACCEPT)",
            "profile": "mature",
            "request": AuthenticateRequest(
                amount=50.0, beneficiary_known=True
            ).model_dump(),
        },
        {
            "id": "finger_otp_fallback",
            "label": "Fingerprint unavailable → OTP fallback",
            "profile": "mature",
            "request": AuthenticateRequest(
                amount=150.0,
                beneficiary_known=True,
                mock_scores=MockScores(voice=0.40, face=0.40, finger=None),
                fingerprint_available=False,
                stage3_mode="finger_or_otp",
                otp_demo=True,
            ).model_dump(),
        },
        {
            "id": "face_replay",
            "label": "Replay attack on face (REJECT)",
            "profile": "mature",
            "request": AuthenticateRequest(
                amount=150.0,
                mock_scores=MockScores(voice=0.35, face=0.12, finger=0.30),
            ).model_dump(),
        },
        {
            "id": "zone_novel_stepup",
            "label": "Out of zone + first-time payee → STEP_UP",
            "profile": "mature",
            "request": AuthenticateRequest(
                amount=150.0,
                beneficiary="new_merchant",
                beneficiary_known=False,
                is_guest=True,
                context=VehicleContext(
                    in_trusted_zone=False,
                    dist_from_home_km=45.0,
                    speed_kmh=0.0,
                ),
            ).model_dump(),
        },
        {
            "id": "accept_micro",
            "label": "Micro payment (ACCEPT)",
            "profile": "mature",
            "request": AuthenticateRequest(
                amount=50.0, beneficiary_known=True
            ).model_dump(),
        },
        {
            "id": "bootstrap_ladder",
            "label": "New driver bootstrap (ACCEPT via demo OTP stage-3, not voice/mock-finger)",
            "profile": "bootstrap",
            "request": AuthenticateRequest(
                amount=50.0,
                beneficiary_known=True,
                fingerprint_available=False,
                stage3_mode="finger_or_otp",
                otp_demo=True,
            ).model_dump(),
        },
        {
            "id": "high_value_ladder",
            "label": "High value (ACCEPT via demo OTP stage-3, not voice/mock-finger)",
            "profile": "mature",
            "request": AuthenticateRequest(
                amount=75_000.0,
                beneficiary_known=False,
                beneficiary="new_merchant",
                fingerprint_available=False,
                stage3_mode="finger_or_otp",
                otp_demo=True,
            ).model_dump(),
        },
        {
            "id": "escalate_face",
            "label": "Low voice → Face ACCEPT",
            "profile": "mature",
            "request": AuthenticateRequest(
                amount=150.0,
                mock_scores=MockScores(voice=0.40, face=0.90, finger=0.40),
            ).model_dump(),
        },
        {
            "id": "low_trust_reject",
            "label": "Low biometrics (REJECT after ladder)",
            "profile": "mature",
            "request": AuthenticateRequest(
                amount=150.0,
                mock_scores=MockScores(voice=0.40, face=0.40, finger=0.40),
            ).model_dump(),
        },
        {
            "id": "risky_context",
            "label": "Risky context + moving",
            "profile": "mature",
            "request": AuthenticateRequest(
                amount=5_000.0,
                beneficiary_known=False,
                context=VehicleContext(
                    speed_kmh=95.0, in_trusted_zone=False, dist_from_home_km=45.0
                ),
            ).model_dump(),
        },
        {
            "id": "guest_stepup",
            "label": "Guest mode (STEP_UP)",
            "profile": "mature",
            "request": AuthenticateRequest(
                amount=150.0,
                is_guest=True,
                beneficiary_known=True,
            ).model_dump(),
        },
    ]
